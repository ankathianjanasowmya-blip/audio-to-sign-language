async function uploadAudio() {

    const file =
        document.getElementById("audioFile")
            .files[0];

    const formData = new FormData();

    formData.append("audio", file);

    const response = await fetch(
        "/convert",
        {
            method: "POST",
            body: formData
        }
    );

    const data = await response.json();

    document.getElementById("text")
        .innerText = data.text;

    document.getElementById("asl")
        .innerText = data.asl;
}