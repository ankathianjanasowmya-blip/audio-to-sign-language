from faster_whisper import WhisperModel

model = WhisperModel("base")

segments, info = model.transcribe("audio.wav")

text = ""

for segment in segments:
    text += segment.text

print(text)