from faster_whisper import WhisperModel

# Load model
model = WhisperModel("base")

# Transcribe audio file
segments, info = model.transcribe("audio.wav")

text = ""

for segment in segments:
    text += segment.text

print("Recognized Text:")
print(text)